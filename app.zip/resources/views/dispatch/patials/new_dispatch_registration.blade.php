
 
<div class="modal fade" id="generic-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="" lass="modal-title" id="exampleModalLabel">@lang('New Dispatch Order')</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
              <div class="modal-body">
                  <form id="myForm" method="post" action="javascript:void(0)">                  
                      <div class="form-group">
                          <h2?>HERR</h2>
                           
                      </div>
                      
                          <button value="Save" class='btn btn-info col-md-12 mb-3' value="Submit" >Save</button>
                  </form>
              </div>
          </div>
      </div>
  </div>